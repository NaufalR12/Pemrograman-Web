<?php
    include "koneksi.php";
	
    $nama	=$_POST['namaMenu'];
    $kategori   =$_POST['kategori'];
    $harga   =$_POST['harga'];
	
    $query=mysqli_query($connect,"INSERT INTO menu 
                        VALUES('','$nama','$kategori','$harga')"
                        ) or die(mysqli_error($connect));
	
    if($query)
    {
	echo "Proses input berhasil, ingin lihat hasil 
            <a href='main.php'> disini </a>";
    }
     else 
   {
     echo "Proses Input gagal";
    }
?>