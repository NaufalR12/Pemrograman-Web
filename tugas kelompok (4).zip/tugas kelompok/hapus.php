<?php
	include "koneksi.php";
	$id_menu	=$_GET['id_menu'];
	$query=mysqli_query($connect,"DELETE FROM menu where 
                           id_menu=$id_menu");
   if($query)
  {
      echo "Proses hapus berhasil, ingin lihat hasil 
            <a href='main.php'> disini  </a>";
  }
   else 
  {
    echo "Proses Input gagal";
  }
?>