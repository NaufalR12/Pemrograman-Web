<?php
session_start();
if (empty($_SESSION['username'])) {
    header("location:index.php?pesan=belum_login");
}

include('koneksi.php');

$nama = $_POST['nama'];
$nomor_telepon = $_POST['nomor_telepon'];
$keluhan = $_POST['keluhan'];
$tanggal_reservasi = $_POST['tanggal'];
$id_dokter = $_POST['id_dokter'];

$today = date("Y-m-d");
if ($tanggal_reservasi < $today) {
    echo "Tanggal yang dipilih sudah lewat. Silakan pilih tanggal yang valid. <a href='reservasi.php'>Kembali</a>";
    exit;
}

$id_pengguna = $_SESSION['id_pengguna'];

$queryJamPraktik = "SELECT jam_praktik FROM dokter WHERE id_dokter = $id_dokter";
$resultJamPraktik = $connect->query($queryJamPraktik);

if ($resultJamPraktik->num_rows > 0) {
    $rowJamPraktik = $resultJamPraktik->fetch_assoc();
    $jam_reservasi = $rowJamPraktik['jam_praktik'];
} else {
    die("Error: Dokter tidak ditemukan.");
}

$queryInsertReservasi = "INSERT INTO reservasi (id_pengguna, id_dokter, keluhan, tanggal_reservasi, jam_reservasi) VALUES ('$id_pengguna', '$id_dokter', '$keluhan', '$tanggal_reservasi', '$jam_reservasi')";
$resultInsertReservasi = $connect->query($queryInsertReservasi);

if ($resultInsertReservasi) {
    $id_reservasi = $connect->insert_id;
    ?>
<div class="container position-absolute top-50 start-50 translate-middle text-center mb-5 ml-5 mr-5 p-5 ">
    <!-- Sisanya sesuai dengan kode yang telah Anda berikan -->
</div>
<?php
} else {
    die("Error: " . $connect->error);
}

$connect->close();
?>