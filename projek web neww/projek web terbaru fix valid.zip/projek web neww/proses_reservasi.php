<?php
session_start();

include('koneksi.php');


// Mendapatkan data dari formulir reservasi
$nama = $_POST['nama'];
$nomor_telepon = $_POST['nomor_telepon'];
$email = $_POST['email'];
$keluhan = $_POST['keluhan'];
$tanggal_reservasi = $_POST['tanggal'];
$id_dokter = $_POST['id_dokter'];

// Misalkan id_pengguna telah disimpan dalam sesi saat login
// Anda perlu menyesuaikan cara Anda menyimpan id_pengguna saat login
$id_pengguna = $_SESSION['id_pengguna']; // Gantilah dengan cara sesuai aplikasi Anda

// Mendapatkan jam_praktik dokter berdasarkan id_dokter
$queryJamPraktik = "SELECT jam_praktik FROM dokter WHERE id_dokter = $id_dokter";
$resultJamPraktik = $connect->query($queryJamPraktik);

if ($resultJamPraktik->num_rows > 0) {
    $rowJamPraktik = $resultJamPraktik->fetch_assoc();
    $jam_reservasi = $rowJamPraktik['jam_praktik'];
} else {
    // Handle jika id_dokter tidak valid
    die("Error: Dokter tidak ditemukan.");
}

// Memasukkan data reservasi ke dalam tabel reservasi
$queryInsertReservasi = "INSERT INTO reservasi (id_pengguna, id_dokter, keluhan, tanggal_reservasi, jam_reservasi) VALUES ('$id_pengguna', '$id_dokter', '$keluhan', '$tanggal_reservasi', '$jam_reservasi')";
$resultInsertReservasi = $connect->query($queryInsertReservasi);

if ($resultInsertReservasi) {
    // Jika reservasi berhasil, tampilkan informasi reservasi
    $id_reservasi = $connect->insert_id; // Mendapatkan id_reservasi yang baru saja dibuat
    echo "Reservasi Berhasil!<br>";
    echo "ID Reservasi: $id_reservasi<br>";
    echo "ID Pengguna: $id_pengguna<br>";
    echo "ID Dokter: $id_dokter<br>";
    echo "Keluhan: $keluhan<br>";
    echo "Tanggal Reservasi: $tanggal_reservasi<br>";
    echo "Jam Reservasi: $jam_reservasi<br>";
} else {
    // Handle jika terjadi kesalahan saat menyimpan reservasi
    die("Error: " . $connect->error);
}

// Tutup koneksi database
$connect->close();
?>
