<?php
// Ambil parameter productID dari URL
$productID = isset($_GET['productID']) ? $_GET['productID'] : die('Missing product ID.');

// Lakukan koneksi ke database
// Gantilah parameter koneksi sesuai dengan konfigurasi database Anda
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "nwind";

$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query untuk mendapatkan informasi produk berdasarkan productID
$sql = "SELECT ProductID, ProductName, UnitPrice FROM products WHERE ProductID = $productID";
$result = $conn->query($sql);

// Ambil data produk
$product = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details</title>
</head>

<body>
    <h1>Product Details</h1>
    <p><strong>Product ID:</strong> <?php echo $product['ProductID']; ?></p>
    <p><strong>Product Name:</strong> <?php echo $product['ProductName']; ?></p>
    <p><strong>Unit Price:</strong> $<?php echo $product['UnitPrice']; ?></p>
</body>

</html>

<?php
// Tutup koneksi database
$conn->close();
?>