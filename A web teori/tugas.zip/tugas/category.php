<?php
// Ambil parameter categoryID dari URL
$categoryID = isset($_GET['categoryID']) ? $_GET['categoryID'] : die('Missing category ID.');

// Lakukan koneksi ke database
// Gantilah parameter koneksi sesuai dengan konfigurasi database Anda
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "nwind";

$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query untuk mendapatkan produk berdasarkan categoryID
$sql = "SELECT ProductID, ProductName, UnitPrice FROM products WHERE CategoryID = $categoryID";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
</head>

<body>
    <h1>Product List</h1>
    <ul>
        <?php
        // Tampilkan daftar produk
        while ($row = $result->fetch_assoc()) {
            echo "<li><a href=\"product.php?productID={$row['ProductID']}\">{$row['ProductName']}</a> - \${$row['UnitPrice']}</li>";
        }
        ?>
    </ul>
</body>

</html>

<?php
// Tutup koneksi database
$conn->close();
?>