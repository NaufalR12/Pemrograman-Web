<?php
session_start();

// Fungsi untuk menambah produk ke keranjang belanja
function addToCart($productID, $productName, $unitPrice, $quantity) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }

    // Cek apakah produk sudah ada di keranjang
    $found = false;
    foreach ($_SESSION['cart'] as $key => $item) {
        if ($item['productID'] == $productID) {
            $_SESSION['cart'][$key]['quantity'] += $quantity;
            $found = true;
            break;
        }
    }

    // Jika produk belum ada di keranjang, tambahkan ke keranjang
    if (!$found) {
        $item = array(
            'productID' => $productID,
            'productName' => $productName,
            'unitPrice' => $unitPrice,
            'quantity' => $quantity
        );
        $_SESSION['cart'][] = $item;
    }
}


// Ambil data dari form pembelian
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productID = $_POST['productID'];
    $productName = $_POST['productName'];
    $unitPrice = $_POST['unitPrice'];
    $quantity = $_POST['quantity'];

    // Tambahkan produk ke keranjang belanja
    addToCart($productID, $productName, $unitPrice, $quantity);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
</head>

<body>
    <h1>Shopping Cart</h1>

    <?php
    // Tampilkan produk dalam keranjang belanja
    if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
        echo "<table border='1'>";
        echo "<thead>";
        echo "<tr>";
        echo "<th>Product Name</th>";
        echo "<th>Quantity</th>";
        echo "<th>Unit Price</th>";
        echo "<th>Subtotal</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";

        foreach ($_SESSION['cart'] as $item) {
            $subtotal = $item['unitPrice'] * $item['quantity'];
            echo "<tr>";
            echo "<td>{$item['productName']}</td>";
            echo "<td>{$item['quantity']}</td>";
            echo "<td>\${$item['unitPrice']}</td>";
            echo "<td>\${$subtotal}</td>";
            echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";

        // Hitung total harga
        $totalPrice = array_sum(array_map(function ($item) {
            return $item['unitPrice'] * $item['quantity'];
        }, $_SESSION['cart']));

        echo "<p><strong>Total Price:</strong> \${$totalPrice}</p>";
    } else {
        echo "<p>Your shopping cart is empty.</p>";
    }
    ?>

    <p><a href="index.php">Back to Category List</a></p>
</body>

</html>