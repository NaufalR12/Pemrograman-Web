<?php 
	include "koneksi.php";
	
	$id_menu=$_POST['id_menu'];
	$namaMenu	=$_POST['namaMenu'];
	$kategori	=$_POST['kategori'];
	$harga	=$_POST['harga'];
	
	$query=mysqli_query($connect,"UPDATE menu SET namaMenu='$namaMenu',
             category='$kategori',price='$harga' where id_menu='$id_menu'") 
             or die(mysqli_error($connect));
     if($query)
    {
	echo "Proses update berhasil, ingin lihat hasil 
             <a href='main.php'> disini </a>";
    }
      else 
    {
      echo "Proses Input gagal";
    }
?>