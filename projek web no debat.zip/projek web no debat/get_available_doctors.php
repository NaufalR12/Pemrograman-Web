$(document).ready(function () {
$("#jam").change(function () {
var selectedTime = $(this).val();

// Lakukan permintaan AJAX untuk mendapatkan dokter yang tersedia berdasarkan jam yang dipilih
$.ajax({
type: "POST",
url: "get_available_doctors.php", // Pastikan path ini benar
data: { selectedTime: selectedTime },
dataType: "json",
success: function (response) {
// Perbarui opsi di dropdown dokter
var doctorDropdown = $("#dokter");
doctorDropdown.empty(); // Kosongkan opsi yang sudah ada

// Tambahkan opsi baru
$.each(response, function (key, value) {
doctorDropdown.append(
'<option value="' +
              value.id_dokter +
              '">' +
    value.nama_dokter +
    " - " +
    value.spesialisasi +
    "</option>"
);
});
},
error: function (xhr, status, error) {
console.error(xhr.responseText);
}
});
});
});